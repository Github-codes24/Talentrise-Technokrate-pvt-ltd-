<?php
require('top.inc.php');
isAdmin();
$paper = '';
$color = '';
$rounded_corner = '';
$coating = '';
$order_by = '';
$msg = '';

if(isset($_GET['id']) && $_GET['id']!=''){
    $id = get_safe_value($con, $_GET['id']);
    $res = mysqli_query($con, "select * from future_product where id='$id'");
    $check = mysqli_num_rows($res);
    if($check > 0){
        $row = mysqli_fetch_assoc($res);
        $paper = $row['paper'];
        $color = $row['color'];
        $rounded_corner = $row['rounded_corner'];
        $coating = $row['coating'];
        $order_by = $row['order_by'];
    }else{
        redirect('size.php');
    }
}

if(isset($_POST['submit'])){
    $paper = get_safe_value($con, $_POST['paper']);
    $color = get_safe_value($con, $_POST['color']);
    $rounded_corner = get_safe_value($con, $_POST['rounded_corner']);
    $coating = get_safe_value($con, $_POST['coating']);
    $order_by = get_safe_value($con, $_POST['order_by']);

    $res = mysqli_query($con, "select * from future_product where paper='$paper'");
    $check = mysqli_num_rows($res);
    if($check > 0){
        if(isset($_GET['id']) && $_GET['id']!=''){
            $getData = mysqli_fetch_assoc($res);
            if($id == $getData['id']) {
                // Same record
            } else {
                $msg = "Product already exists";
            }
        } else {
            $msg = "Product already exists";
        }
    }
    
    if($msg == ''){
        if(isset($_GET['id']) && $_GET['id']!=''){
            mysqli_query($con, "update future_product set paper='$paper', color='$color', rounded_corner='$rounded_corner', coating='$coating', order_by='$order_by' where id='$id'");
        } else {
            mysqli_query($con, "insert into future_product(paper, color, rounded_corner, coating, order_by, status) values('$paper', '$color', '$rounded_corner', '$coating', '$order_by', '1')");
        }
        redirect('future_product.php');
    }
}
?>

<div class="content pb-0">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><strong>Future Product</strong><small> Form</small></div>
                    <form method="post">
                        <div class="card-body card-block">
                            <div class="form-group">
                                <label for="paper" class="form-control-label">Paper</label>
                                <input type="text" name="paper" placeholder="Enter paper name" class="form-control" required value="<?php echo $paper ?>">
                            </div>
                            <div class="form-group">
                                <label for="color" class="form-control-label">Color</label>
                                <input type="text" name="color" placeholder="Enter color name" class="form-control" required value="<?php echo $color ?>">
                            </div>
                            <div class="form-group">
                                <label for="rounded_corner" class="form-control-label">Rounded Corner</label>
                                <input type="text" name="rounded_corner" placeholder="Enter rounded corner name" class="form-control" required value="<?php echo $rounded_corner ?>">
                            </div>
                            <div class="form-group">
                                <label for="coating" class="form-control-label">Coating</label>
                                <input type="text" name="coating" placeholder="Enter coating name" class="form-control" required value="<?php echo $coating ?>">
                            </div>
                            <div class="form-group">
                                <label for="order_by" class="form-control-label">Order By</label>
                                <input type="text" name="order_by" placeholder="Enter order by" class="form-control" required value="<?php echo $order_by ?>">
                            </div>
                            <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
                                <span id="payment-button-amount">Submit</span>
                            </button>
                            <div class="field_error"><?php echo $msg ?></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
