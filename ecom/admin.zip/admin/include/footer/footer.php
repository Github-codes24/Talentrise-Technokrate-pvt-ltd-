<div class="section-body">
   <footer class="footer">
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-6 col-sm-12">
               <a href="templateshub.net">@ 2024 copyright: qprint@gmail.com</a>
            </div>
            <div class="col-md-6 col-sm-12 text-md-right">
               <ul class="list-inline mb-0">
                  <li class="list-inline-item"><a href="doc/index.html"><?php echo $site_name; ?></a></li>
               </ul>
            </div>
         </div>
      </div>
   </footer>
</div>