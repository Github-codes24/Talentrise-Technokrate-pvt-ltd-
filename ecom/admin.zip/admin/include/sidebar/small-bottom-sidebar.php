<div id="header_top" class="header_top">
    <div class="container">
        <div class="hleft">
            <!-- <a class="header-brand" href="index.php"><img class="" src="images/logo.png" alt="logo"></a> -->
            <div class="dropdown">
                <a href="javascript:void(0)" class="nav-link user_btn"><img class="avatar" src="assets/images/user.png"
                        alt="" data-toggle="tooltip" data-placement="right" title="User Menu" /></a>

            </div>
        </div>
        <div class="hright">
            <div class="dropdown">
                <a href="javascript:void(0)" class="nav-link icon settingbar"><i class="fa fa-gear fa-spin"
                        data-toggle="tooltip" data-placement="right" title="Settings"></i></a>
                <a href="javascript:void(0)" class="nav-link icon menu_toggle"><i class="fa  fa-align-left"></i></a>
            </div>
        </div>
    </div>
</div>