<!-- Bootstrap Core and vandor -->
<link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css" />

<!-- Plugins css -->
<link rel="stylesheet" href="assets/plugins/charts-c3/c3.min.css"/>

<!-- Core css -->
<link rel="stylesheet" href="assets/css/main.css"/>
<link rel="stylesheet" href="assets/css/theme1.css"/>

<!-- font awesome cdn -->
<link rel="stylesheet" href="assets/plugins/font-awesome/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<!-- custom-alert -->
<link rel="stylesheet" href="../assets/custom_alert/css/alert.css" />
<link rel="stylesheet" href="../assets/custom_alert/css/confirm-alert.css" />
