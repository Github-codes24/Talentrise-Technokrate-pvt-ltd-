<script src="assets/bundles/lib.vendor.bundle.js"></script>

<script src="assets/bundles/apexcharts.bundle.js"></script>
<script src="assets/bundles/counterup.bundle.js"></script>
<script src="assets/bundles/knobjs.bundle.js"></script>
<script src="assets/bundles/c3.bundle.js"></script>

<script src="assets/js/core.js"></script>
<!-- <script src="assets/js/page/project-index.js"></script> -->
<!-- jquery cdn -->
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script> -->

<!-- ajax handler -->
<script src="../js/requestHandler.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<!-- utils -->
<script src="../js/utils.js"></script>
<!-- custome alert -->
<script src="../assets/custom_alert/js/alert.js"></script>
<script src="../assets/custom_alert/js/confirm-alert.js"></script>